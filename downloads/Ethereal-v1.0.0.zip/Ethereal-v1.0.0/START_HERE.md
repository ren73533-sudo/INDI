# 幽玄 — Ethereal v1.0.0

Open `indicators/ethereal.pine`, copy the ENTIRE file into a new TradingView Pine Editor indicator, save and add it to NQ1! using standard candles.

Only unlabelled boxes are drawn:
- Green: at least two distinct strategy types align.
- Yellow: all four types align, including an RB at or above the chosen reference timeframe and the configured VAH/VAL reversal.

The reference timeframe defaults to 5m, independently of the display chart. Supported displays: 1m, 5m, 10m, 15m, 30m, 1h and 4h. Colors, tolerance, minimum height, padding and duration are customizable. Box coordinates use fixed timestamps and prices; keep the indicator on NQ's price scale.

Read `docs/ETHEREAL.md` for exact rules, settings and history behavior. No Node.js or external files are needed in TradingView. Official TradingView compilation / live-chart behavior and real-market reversal performance remain unverified.

The original full-display indicator is included separately as `indicators/nq_key_levels.pine`. Development sources and offline tests are included; Node.js 22+ is needed only for them. From this folder, run `npm ci --ignore-scripts --no-audit --no-fund --cache /tmp/indi-npm-cache`, then `npm test`. Run `npm run build:ethereal` after changing the shared engine or new indicator templates.
