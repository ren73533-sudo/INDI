# 幽玄 — Ethereal v1.2.0

Open `indicators/ethereal.pine`, copy the ENTIRE file into a new TradingView Pine Editor indicator, save and add it to NQ1! using standard candles. Replace the complete older Ethereal script.

Version 1.2 fixes the last-bar-only export and drawing gates that left earlier Bar Replay cursors without zones. It exports compact historical zone state on each available source bar and updates drawings on each available chart bar. A later invalidation does not erase an earlier cursor's zones.

The resting horizontal areas, original price/start anchors, strategy and settings are preserved. Green = at least two distinct concept types, in any order. Yellow = all four plus the configured VAH/VAL reversal and an RB at or above the reference timeframe (default 5m). No text, individual levels or arrows are drawn. A normal return tap does not delete the area; price invalidation, optional expiry and retention limits still apply.

Supported displays: 1m, 5m, 10m, 15m, 30m, 1h and 4h. Keep the indicator on NQ's price scale. Zone height, tolerance, padding, colors, right projection and other calibration remain configurable.

For replay, load overnight and prior-session history and allow at least one new source minute for the completed-minute snapshot. Engine history defaults to 6,000 one-minute candles, adjustable subject to feed/account availability. A cursor outside source coverage, missing warmup or fewer than two available concept types produces no box. Invalidated areas are hidden by default; turn on Show invalidated / expired zones to inspect retained broken areas.

Read `docs/ETHEREAL.md` for exact rules and validation limits. No Node.js or other files are needed in TradingView. Native TradingView compilation, Bar Replay and live-chart behavior still require chart testing; synthetic software checks are not a reversal-performance backtest. If TradingView shows an error, record its exact text.

The original full-display indicator is included separately as `indicators/nq_key_levels.pine`. Development sources and tests are included; Node.js 22+ is needed only for them. Run `npm ci --ignore-scripts --no-audit --no-fund --cache /tmp/indi-npm-cache`, then `npm run check:ethereal` and `npm test`. After changing the shared engine or templates, run `npm run build:ethereal`.
