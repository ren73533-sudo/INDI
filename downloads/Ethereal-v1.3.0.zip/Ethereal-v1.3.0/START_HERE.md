# 幽玄 — Ethereal v1.3.0

Open `indicators/ethereal.pine`, copy the ENTIRE file into a new TradingView Pine Editor indicator, save and add it to NQ1! using standard candles. Replace the complete older Ethereal script. The indicator declares Pine Script v6.

New in v1.3:

- Optional text lists the concept families that actually formed the zone, including contributing RB timeframes. Example: ρ  STDV | VWAP | VAH | RB 10m.
- β marks a support / buy-reversal area. ρ marks a resistance / sell-reversal area. These describe the zone's fixed side, not a confirmed entry or guaranteed reversal.
- Show confluence text and Show reversal side symbol are independent toggles, both ON by default. Color and size are configurable; turn both OFF for empty boxes. No OTE is implemented.
- Optional RB zone placement → Beyond wick confluence centers a band on an existing aligned level beyond the RB wick. RB stacks without such a level are skipped. Non-RB pairs retain their original rules. Original anchor is still the default.
- Optional Hide zones after first return hides an area after a completed 1m overlap following formation and skips creation on a candle that already reaches the band. Default OFF.

To try the new sweep behavior, choose Beyond wick confluence and enable Hide zones after first return in Settings → Boxes. Keep text/symbols ON if wanted. Minimum sweep distance, zone height, padding, tolerance, colors, projection and source calibration remain configurable. The outer level must be within tolerance and before the RB's price-invalidation threshold. These changes may reduce zones and omit areas shown under the original mode; improved reversal precision has not been measured.

Green = at least two distinct concept types in any order. Yellow = all four plus the configured VAH/VAL reversal and an RB at or above the reference timeframe (default 5m). Formation prices and start timestamps remain fixed; a later yellow upgrade keeps earlier green text/history. The historical Bar Replay correction from v1.2 is retained.

Supported displays: 1m, 5m, 10m, 15m, 30m, 1h and 4h. Keep the indicator on NQ's price scale. For replay, load overnight and prior-session history, and allow a new source minute for the completed-minute snapshot. Engine history defaults to 6,000 one-minute candles, adjustable subject to feed/account availability. Missing source coverage, incomplete warmup or fewer than two eligible types produces no box. Broken zones are hidden by default.

Read `docs/ETHEREAL.md` for exact rules, mode tradeoffs and validation limits. No Node.js or other files are needed in TradingView. Offline checks use PineTS and synthetic candles. Native TradingView compilation/replay/live behavior and actual NQ reversal accuracy require chart tests. Exact top/bottom-tick entries are not guaranteed.

The original full-display indicator remains included separately as `indicators/nq_key_levels.pine`. Development sources and tests are included; Node.js 22+ is needed only for them. Run `npm ci --ignore-scripts --no-audit --no-fund --cache /tmp/indi-npm-cache`, then `npm run check:ethereal` and `npm test`. After changing the shared engine or templates, run `npm run build:ethereal`.
