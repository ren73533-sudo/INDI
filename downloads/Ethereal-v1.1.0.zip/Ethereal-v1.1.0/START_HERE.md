# 幽玄 — Ethereal v1.1.0

Open `indicators/ethereal.pine`, copy the ENTIRE file into a new TradingView Pine Editor indicator, save and add it to NQ1! using standard candles. Replace the old v1.0 script completely.

Version 1.1 draws resting horizontal reversal areas instead of tiny moving alignment fragments. A zone is established from at least two distinct strategy types, then stays at its original prices while the moving references change. It projects right for later return taps until price invalidation, optional expiry or retention limits. A normal tap does not delete it. Invalidated zones are hidden by default.

Green = two or more distinct types. Yellow = all four plus the configured VAH/VAL reversal and an RB at or above the reference timeframe (default 5m, independently of the chart). No sequencing of confluences is required. No text, individual levels or arrows are drawn.

Zone height is now a fixed point setting by default, separate from confluence tolerance. Height, padding, colors, right projection and optional expiry are configurable. `Cover confluence span` sizing remains available. Supported displays: 1m, 5m, 10m, 15m, 30m, 1h and 4h. Keep the indicator on NQ's price scale.

Read `docs/ETHEREAL.md` for exact rules, settings and retention behavior. No Node.js or other files are needed in TradingView. TradingView compilation and live chart behavior still require a chart test; no reversal-performance result is claimed.

The original full-display indicator remains included as `indicators/nq_key_levels.pine`. Development sources and offline tests are included; Node.js 22+ is needed only for them. Run `npm ci --ignore-scripts --no-audit --no-fund --cache /tmp/indi-npm-cache`, then `npm test`. After changing the shared engine or templates, run `npm run build:ethereal`.
